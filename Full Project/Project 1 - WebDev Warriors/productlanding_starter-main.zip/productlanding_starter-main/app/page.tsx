import React from "react";

const HomePage = () => {
  return <div className="text-5xl text-red-800">HomePage Get Started</div>;
};

export default HomePage;
